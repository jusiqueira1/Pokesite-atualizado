
// const botaogerar = document.querySelector('.a-botao-1');
// const botaoBatalha = document.querySelector('.a-botao-2');

// botaogerar.addEventListener('click', async () => {
//     await getPokemon();
// });

// botaoBatalha.addEventListener('click', () => {
//     battlePokemon();
// });

// const getPokemon = async () => {
//     const randomNumberOne = getUniqueNumber(pokeHistory, 807) + 1;
//     const randomNumberTwo = getUniqueNumber(pokeHistory, 807) + 1;
//     const randomNumberThree = getUniqueNumber(pokeHistory, 807) + 1;

//     const pokeDataArr = await pokemonDataSync(randomNumberOne, randomNumberTwo, randomNumberThree);
//     await renderPokemonSync(pokeDataArr);
// };

// const pokemonDataSync = async (num1, num2, num3) => {
//     let pokeDataArr = [];
//     const pokemonOne = await makeApiCall(num1);
//     const pokemonTwo = await makeApiCall(num2);
//     const pokemonThree = await makeApiCall(num3);

//     pokeDataArr.push(pokemonOne);
//     pokeDataArr.push(pokemonTwo);
//     pokeDataArr.push(pokemonThree);

//     return pokeDataArr;
// };

// const renderPokemonSync = (pokeDataArr) => {
//     pokeDataArr.forEach(pokemonData => displayPokemonData(pokemonData));
// };

// const getNewPokemon = async () => {
//     document.querySelector('.data').innerHTML = '';
//     await getPokemon();
// };

// const battlePokemon = () => {
//     const randomNumber = Math.random();
//     const battleResult = document.createElement('p');
//     const battleHistory = document.querySelector('#history');
//     const pokemonOne = document.querySelectorAll('.h4-nome')[0].innerText;
//     const pokemonTwo = document.querySelectorAll('.h4-nome')[1].innerText;
//     const pokemonThree = document.querySelectorAll('.h4-nome')[2].innerText;

//     if (randomNumber < 0.5) {
//         battleResult.innerText = `${pokemonOne} defeated ${pokemonTwo}`;
//     } else {
//         battleResult.innerText = `${pokemonTwo} defeated ${pokemonOne}`;
//     }

//     battleHistory.prepend(battleResult);
//     getNewPokemon();
// };

// const getUniqueNumber = (history, max) => {
//     const ranNum = Math.floor(Math.random() * max);
//     if (!history.includes(ranNum)) {
//         history.push(ranNum);
//         return ranNum;
//     } else {
//         return getUniqueNumber(history, max);
//     }
// };

// const makeApiCall = async (ranNum) => await axios.get(`https://pokeapi.co/api/v2/pokemon/${ranNum}`);


// const displayPokemonData = async (data) => {
//     const name = document.querySelector('.h4-nome');
//     const img = document.querySelector('.imagem-1');

//     name.innerText = data.data.name;
//     img.src = data.data.sprites.front_shiny;

//     if (data.data.sprites.back_shiny != null) {
//         img.addEventListener('mouseover', () => {
//             img.style.transition = '.5s ease';
//             img.src = data.data.sprites.back_shiny;
//         });
//     }

//     img.addEventListener('mouseleave', () => {
//         img.style.transition = '.5s ease';
//         img.src = data.data.sprites.front_shiny;
//     });
// };
// Código JavaScript para simular a batalha entre Pokémon
document.addEventListener('DOMContentLoaded', () => {
    const gerarBatalhaBtn = document.getElementById('a-botao-1');
    const cards = document.querySelectorAll('.card');
  
    class Pokemon {
      constructor(nome, tipo, ataque, defesa, sprite) {
        this.nome = nome;
        this.tipo = tipo;
        this.ataque = ataque;
        this.defesa = defesa;
        this.vida = 100; // Vida inicial
        this.sprite = sprite; // URL do sprite do Pokémon
      }
  
      atacar(outroPokemon) {
        const dano = this.ataque - outroPokemon.defesa;
        outroPokemon.vida -= dano > 0 ? dano : 0;
        return dano > 0 ? dano : 0;
      }
    }
  
    const fetchPokemon = async () => {
      const response1 = await fetch('https://pokeapi.co/api/v2/pokemon/1'); // Exemplo de requisição para o Pokémon com ID 1 (Pikachu)
      const data1 = await response1.json();
      const pikachu = new Pokemon(
        data1.name,
        data1.types[0].type.name,
        data1.stats[1].base_stat,
        data1.stats[2].base_stat,
        data1.sprites.front_default
      );
  
      const response2 = await fetch('https://pokeapi.co/api/v2/pokemon/4'); // Exemplo de requisição para o Pokémon com ID 4 (Charmander)
      const data2 = await response2.json();
      const charmander = new Pokemon(
        data2.name,
        data2.types[0].type.name,
        data2.stats[1].base_stat,
        data2.stats[2].base_stat,
        data2.sprites.front_default
      );
  
      return [pikachu, charmander];
    };
  
    const atualizarStatus = (card, pokemon) => {
      const vidaPokemon = card.querySelector('.h4-nome');
      vidaPokemon.textContent = `${pokemon.nome} (${pokemon.vida} HP)`;
  
      const imagemPokemon = card.querySelector('.imagem-1');
      imagemPokemon.src = pokemon.sprite; // Atualiza a imagem do card com o sprite do Pokémon
    };
  
    const realizarBatalha = async () => {
      const [pikachu, charmander] = await fetchPokemon();
  
      const danoPikachu = pikachu.atacar(charmander);
      const danoCharmander = charmander.atacar(pikachu);
  
      atualizarStatus(cards[0], pikachu);
      atualizarStatus(cards[1], charmander);
  
      alert(`${pikachu.nome} atacou ${charmander.nome} e causou ${danoPikachu} de dano!`);
      alert(`${charmander.nome} atacou ${pikachu.nome} e causou ${danoCharmander} de dano!`);
  
      if (pikachu.vida <= 0) {
        alert(`${charmander.nome} vence a batalha! Você perdeu.`);
        window.location.href = 'index3.html'; // Redirecionamento para a página de derrota
      } else if (charmander.vida <= 0) {
        alert(`${pikachu.nome} vence a batalha!`);
      }
    };
  
    gerarBatalhaBtn.addEventListener('click', realizarBatalha);
  });
  

