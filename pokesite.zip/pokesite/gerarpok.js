let pokeHistory = [];


const botaogerar = document.querySelector('.a-botao-1');
const botaoBatalha = document.querySelector('.a-botao-2');


botaogerar.addEventListener('click', async () => {
    const start = Date.now();
    await getPokemon();

})

botaoBatalha.addEventListener('click', () => {
    battlePokemon();
})


const getPokemon = async () => {
    const randomNumberOne = getUniqueNumber(pokeHistory, 807) + 1;
    const randomNumberTwo = getUniqueNumber(pokeHistory, 807) + 1;

    const pokeDataArr = await pokemonDataSync(randomNumberOne, randomNumberTwo);
    await renderPokemonSync(pokeDataArr);
}

const pokemonDataSync = async (num1, num2) => {
    let pokeDataArr = [];
    const pokemonOne = await makeApiCall(num1);
    const pokemonTwo = await makeApiCall(num2);

    pokeDataArr.push(pokemonOne);
    pokeDataArr.push(pokemonTwo);

    return await pokeDataArr;
}

const renderPokemonSync = (pokeDataArr) => {
    displayPokemonData(pokeDataArr[0]);
    displayPokemonData(pokeDataArr[1]);
}

// Aqui é a variavel para receber novo pokemon.
const getNewPokemon = async () => {
    document.querySelector('.data').innerHTML = '';
    const start2 = Date.now();
    await getPokemon();
}

// Aqui ocorre a batalha dos pokemons ,sendo colocado sua história,nome e recebe defesas se número for menor que 5.
const battlePokemon = () => {
    const randomNumber = Math.random();
    const battleResult = document.createElement('p');
    const battleHistory = document.querySelector('#history');
    const pokemonOne = document.querySelectorAll('.pokemon-name')[0].innerText;
    const pokemonTwo = document.querySelectorAll('.pokemon-name')[1].innerText;

    if (randomNumber < .5) {
        battleResult.innerText = `${pokemonOne} defeated ${pokemonTwo}`;
        battleHistory.prepend(battleResult);
        getNewPokemon();
    } else {
        battleResult.innerText = `${pokemonTwo} defeated ${pokemonOne}`
        battleHistory.prepend(battleResult);
        getNewPokemon();
    }
}

// Aqui a variável recebe o histórico da batalha
const getUniqueNumber = (history, max) => {
    const ranNum = Math.floor(Math.random() * max);
    if (!history.includes(ranNum)) {
        history.push(ranNum);
        return ranNum;
    } else {
        return getUniqueNumber(history, max);
    }
}

const makeApiCall = async (ranNum) => await axios.get(`https://pokeapi.co/api/v2/pokemon/${ranNum}`);


const displayPokemonData = async (data) => {
    const name = document.querySelector('.h4-nome');
    const img = document.querySelector('.imagem-1');


    name.innerText = data.data.name;
    img.src = data.data.sprites.front_shiny;


    if (data.data.sprites.back_shiny != null) {
        img.addEventListener('mouseover', () => {
            img.style.transition = '.5s ease';
            img.src = data.data.sprites.back_shiny;
        })
    }
    
    img.addEventListener('mouseleave', () => {
        img.style.transition = '.5s ease';
        img.src = data.data.sprites.front_shiny;
    })

};