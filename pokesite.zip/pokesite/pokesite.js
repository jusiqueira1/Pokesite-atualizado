var botao = document.querySelector('#botao-1');
botao.addEventListener('click', function(event){
    localStorage["botao"] = 0;
    window.location.href= 'batalha.html';
});